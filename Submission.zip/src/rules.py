import re
from typing import List
from rapidfuzz import process, fuzz

# Email tokenization patterns with improved matching
EMAIL_TOKEN_PATTERNS = [
    (r'\b\(?(at|@)\)?\b', '@'),
    (r'\b(dot)\b', '.'),
    (r'\s*@\s*', '@'),
    (r'\s*\.\s*', '.'),
    # Additional patterns for common ASR errors
    (r'\bcom\b', '.com'),
    (r'\bco\.uk\b', '.co.uk'),
]

def collapse_spelled_letters(s: str) -> str:
    """Collapse sequences like 'g m a i l' -> 'gmail' and 'g mailcom' -> 'gmail.com'"""
    tokens = s.split()
    out = []
    i = 0
    while i < len(tokens):
        # Look ahead for sequences of single letters (up to 5)
        seq_len = 0
        for j in range(i, min(i + 5, len(tokens))):
            if len(tokens[j]) == 1 and tokens[j].isalpha():
                seq_len += 1
            else:
                break
        
        if seq_len >= 2:  # At least 2 letters to collapse
            collapsed = ''.join(tokens[i:i+seq_len])
            # Check if next token is a partial domain (like 'mailcom', 'gmailcom')
            if i + seq_len < len(tokens) and len(tokens[i + seq_len]) > 2:
                next_token = tokens[i + seq_len].lower()
                if 'com' in next_token or 'co' in next_token or 'org' in next_token:
                    # Merge domain-like tokens
                    collapsed += '.' + next_token
                    i += seq_len + 1
                else:
                    out.append(collapsed)
                    i += seq_len
            else:
                out.append(collapsed)
                i += seq_len
        else:
            out.append(tokens[i])
            i += 1
    return ' '.join(out)

def normalize_email_tokens(s: str) -> str:
    """Normalize email-like patterns with robust spacing and partial domain handling."""
    s2 = collapse_spelled_letters(s)
    
    # Apply token patterns
    for pat, rep in EMAIL_TOKEN_PATTERNS:
        s2 = re.sub(pat, rep, s2, flags=re.IGNORECASE)
    
    # Remove spaces around @ and . inside emails
    s2 = re.sub(r'\s*([@\.])\s*', r'\1', s2)
    
    # Handle partial domain patterns like 'gmailcom' -> 'gmail.com'
    s2 = re.sub(r'(\w+)(com|co|org|net|info|edu)(\s|$)', r'\1.\2\3', s2, flags=re.IGNORECASE)
    
    # Clean up multiple dots
    s2 = re.sub(r'\.{2,}', '.', s2)
    
    return s2

# Numbers: handle 'double nine', 'triple zero', 'oh' for zero
# Enhanced mapping for robust number recognition (conservative to avoid false positives)
NUM_WORD = {
    'zero':'0', 'oh':'0', 'o':'0',
    'one':'1', 
    'two':'2', 'to':'2',  # 'too' removed - risky
    'three':'3', 'tree':'3',
    'four':'4', 
    'five':'5',
    'six':'6',
    'seven':'7',
    'eight':'8',  # 'ate' removed - risky
    'nine':'9'
}

def words_to_digits(seq: List[str]) -> str:
    """Convert spoken number words to digits, handling doubles/triples."""
    out = []
    i = 0
    while i < len(seq):
        tok = seq[i].lower()
        
        # Handle double/triple prefixes
        if tok in ('double', 'triple') and i + 1 < len(seq):
            times = 2 if tok == 'double' else 3
            nxt = seq[i + 1].lower()
            if nxt in NUM_WORD:
                out.append(NUM_WORD[nxt] * times)
                i += 2
                continue
        
        # Direct digit words
        if tok in NUM_WORD:
            out.append(NUM_WORD[tok])
            i += 1
        else:
            # Stop on first non-number word
            break
    
    return ''.join(out)

def normalize_numbers_spoken(s: str) -> str:
    """Replace spoken digit sequences with numeric digits, with window-based detection."""
    tokens = s.split()
    out = []
    i = 0
    
    while i < len(tokens):
        tok = tokens[i].lower()
        
        # Check if current token starts a number sequence
        if tok in NUM_WORD or tok in ('double', 'triple'):
            # Greedy capture: consume up to 10 consecutive number-related tokens
            j = i
            while j < min(i + 10, len(tokens)):
                next_tok = tokens[j].lower()
                if next_tok in NUM_WORD or next_tok in ('double', 'triple'):
                    j += 1
                else:
                    break
            
            # Convert the identified numeric sequence
            num_window = tokens[i:j]
            wd = words_to_digits(num_window)
            
            if len(wd) >= 1:
                out.append(wd)
                i = j
            else:
                out.append(tokens[i])
                i += 1
        else:
            out.append(tokens[i])
            i += 1
    
    return ' '.join(out)

def normalize_currency(s: str) -> str:
    """Replace 'rupees' with ₹ and apply Indian digit grouping to currency amounts."""
    # Replace 'rupees', 'rupees', 'rs', 'rs.' with ₹
    s = re.sub(r'\b(rupees|rupees|rs\.?)\s+', '₹', s, flags=re.IGNORECASE)
    
    def indian_group(num_str):
        """Format number with Indian grouping: last 3, then every 2 digits."""
        num_str = str(num_str).strip()
        if len(num_str) <= 3:
            return num_str
        
        last3 = num_str[-3:]
        rest = num_str[:-3]
        parts = []
        
        while len(rest) > 2:
            parts.insert(0, rest[-2:])
            rest = rest[:-2]
        
        if rest:
            parts.insert(0, rest)
        
        return ','.join(parts + [last3])
    
    def repl(m):
        raw = re.sub('[^0-9]', '', m.group(0))
        if not raw:
            return m.group(0)
        try:
            return '₹' + indian_group(raw)
        except:
            return m.group(0)
    
    # Match ₹ followed by numbers and commas/dots
    s = re.sub(r'₹\s*[0-9][0-9,\.\s]*', repl, s)
    
    # Also handle standalone digit sequences that might be currency
    s = re.sub(r'(?<=\s)([0-9]{4,})(?=\s|$)', lambda m: indian_group(m.group(1)), s)
    
    return s

def correct_names_with_lexicon(s: str, names_lex: List[str], threshold: int = 85) -> str:
    """Fuzzy-correct names using lexicon with optimized threshold."""
    tokens = s.split()
    out = []
    
    for t in tokens:
        # Skip common non-name words and very short tokens
        if t.lower() in ('a', 'the', 'and', 'or', 'is', 'at', 'by', 'to', 'i', 'me'):
            out.append(t)
            continue
        
        # Try fuzzy matching against lexicon
        if len(t) >= 2:  # Minimum name length
            best = process.extractOne(t, names_lex, scorer=fuzz.ratio)
            if best and best[1] >= threshold:
                out.append(best[0])
            else:
                out.append(t)
        else:
            out.append(t)
    
    return ' '.join(out)

def generate_candidates(text: str, names_lex: List[str]) -> List[str]:
    """Generate diverse correction candidates efficiently, prioritizing high-quality outputs."""
    cands = []
    
    # Candidate 1: Full pipeline (most aggressive)
    t1 = normalize_email_tokens(text)
    t1 = normalize_numbers_spoken(t1)
    t1 = normalize_currency(t1)
    t1 = correct_names_with_lexicon(t1, names_lex)
    cands.append((t1, 1.0))  # Highest priority

    # Candidate 2: Email + names only (for safety on non-commercial text)
    t2 = normalize_email_tokens(text)
    t2 = correct_names_with_lexicon(t2, names_lex)
    cands.append((t2, 0.9))

    # Candidate 3: Numbers + currency only (for numeric contexts)
    t3 = normalize_numbers_spoken(text)
    t3 = normalize_currency(t3)
    cands.append((t3, 0.85))

    # Candidate 4: Original text (fallback)
    cands.append((text, 0.7))

    # Deduplicate: keep first occurrence of each unique text
    seen = set()
    out = []
    for cand_text, priority in cands:
        if cand_text not in seen:
            seen.add(cand_text)
            out.append(cand_text)
    
    return out[:4]  # Cap at 4 candidates for speed
