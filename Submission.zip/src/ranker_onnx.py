from typing import List, Tuple, Optional
import numpy as np
import re

# Optional imports guarded to allow partial environments
try:
    import onnxruntime as ort  # type: ignore
except Exception:
    ort = None

try:
    import torch
    from transformers import AutoTokenizer, AutoModelForMaskedLM
except Exception:
    torch = None
    AutoTokenizer = None
    AutoModelForMaskedLM = None


EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
PHONE_RE = re.compile(r"\b(?:\+91|0)?[6-9]\d{9}\b")
DIGIT_RE = re.compile(r"\d+")


class PseudoLikelihoodRanker:
    """Pseudo-likelihood ranker with practical heuristics for short English
    utterances (Indian-accent ASR postprocessing).

    Improvements over the minimal version:
      - token length caps (configurable)
      - short-circuiting: if a candidate contains a valid email or phone number,
        it is immediately preferred (useful for contact extraction tasks)
      - smarter masking: skip punctuation / email / phone tokens and cap number
        of mask positions to a reasonable budget for speed
      - small length penalty so very long candidates are de-prioritised
    """

    def __init__(
        self,
        model_name: str = "distilbert-base-uncased",
        onnx_path: Optional[str] = None,
        device: str = "cpu",
        max_length: int = 2,
        max_mask_positions: int = 2,
        length_penalty: float = 0.0,
        prefer_contact_shortcircuit: bool = True,
    ):
        self.max_length = max_length
        self.model_name = model_name
        self.onnx = None
        self.torch_model = None
        self.device = device
        self.tokenizer = None
        # heuristics
        self.max_mask_positions = max_mask_positions
        self.length_penalty = length_penalty
        self.prefer_contact_shortcircuit = prefer_contact_shortcircuit

        if onnx_path and ort is not None:
            self._init_onnx(onnx_path)
        elif AutoTokenizer is not None and AutoModelForMaskedLM is not None:
            self._init_torch()
        else:
            raise RuntimeError(
                "Neither onnxruntime nor transformers/torch are available. Please install requirements."
            )

    def _init_onnx(self, onnx_path: str):
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        sess_options = ort.SessionOptions()
        sess_options.intra_op_num_threads = 1
        sess_options.inter_op_num_threads = 1
        self.onnx = ort.InferenceSession(
            onnx_path, sess_options=sess_options, providers=["CPUExecutionProvider"]
        )

    def _init_torch(self):
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.torch_model = AutoModelForMaskedLM.from_pretrained(self.model_name)
        self.torch_model.eval()
        self.torch_model.to(self.device)

    # --------------------- small helpers ---------------------
    @staticmethod
    def _has_valid_email(text: str) -> bool:
        return bool(EMAIL_RE.search(text))

    @staticmethod
    def _has_valid_phone(text: str) -> bool:
        return bool(PHONE_RE.search(text))

    def _token_length_ok(self, input_ids: np.ndarray) -> bool:
        # disallow extremely long tokenized inputs (tokenizer may truncate later)
        L = input_ids.shape[1]
        return L <= self.max_length

    def _select_mask_positions(self, input_ids: np.ndarray, attention_mask: np.ndarray) -> List[int]:
        """Choose which positions to mask for pseudo-likelihood scoring.

        Strategy:
          - consider only positions inside attention_mask
          - skip special tokens (position 0 and last valid pos)
          - skip tokens that look like punctuation or digits-only or part of an email/phone
          - sample or truncate positions to self.max_mask_positions
        """
        toks = input_ids[0]
        L = int(attention_mask[0].sum())
        if L <= 2:
            return []

        candidate_positions: List[int] = []
        for pos in range(1, L - 1):
            tok = toks[pos]
            # decode token to string piece to inspect (fast heuristic)
            piece = self.tokenizer.convert_ids_to_tokens(int(tok))
            piece_stripped = piece.strip().lower()

            # Skip mask if it looks like punctuation / special / subword markers
            if piece_stripped in {"[sep]", "[cls]", "[pad]", "<sep>", "<cls>", "<pad>"}:
                continue
            if all(ch in "-_.:,;!?'\"/\\()[]{}" for ch in piece_stripped):
                continue
            # skip pure digit tokens (we still allow some numeric masking, but often ASR errors are in words)
            if DIGIT_RE.fullmatch(piece_stripped):
                continue

            # skip tokens that are clearly part of emails / at-sign / domain pieces
            if "@" in piece_stripped or "gmail" in piece_stripped or "yahoo" in piece_stripped:
                continue

            candidate_positions.append(pos)

        if not candidate_positions:
            # fallback: choose all non-special positions
            candidate_positions = list(range(1, L - 1))

        # If too many positions, preferentially sample uniformly to cover the sequence
        if len(candidate_positions) > self.max_mask_positions:
            # take first, last and evenly spaced ones to preserve context
            # avoid division by zero when max_mask_positions <= 2
            denom = max(1, self.max_mask_positions - 2)
            step = max(1, len(candidate_positions) // denom)
            chosen = [candidate_positions[0]]
            chosen += candidate_positions[1:-1:step]
            chosen.append(candidate_positions[-1])
            chosen = chosen[: self.max_mask_positions]
            return chosen

        return candidate_positions

    # --------------------- scoring functions ---------------------
    def _score_with_onnx(self, text: str) -> float:
        toks = self.tokenizer(
            text, return_tensors="np", truncation=True, max_length=self.max_length
        )
        input_ids = toks["input_ids"]  # (1, L)
        attn = toks["attention_mask"]  # (1, L)

        # quick token-length check
        if not self._token_length_ok(input_ids):
            # strongly penalize too-long inputs (so shorter alternatives are preferred)
            return -1e6

        # select mask positions using heuristics
        positions = self._select_mask_positions(input_ids, attn)
        if not positions:
            return -1e6

        mask_id = self.tokenizer.mask_token_id
        seq = input_ids[0]
        total = 0.0

        # For ONNX we do single-row runs to remain memory-light and robust across setups
        for pos in positions:
            masked = seq.copy()
            orig_token_id = int(masked[pos])
            masked[pos] = mask_id

            ort_inputs = {
                "input_ids": masked[None, :].astype(np.int64),
                "attention_mask": attn.astype(np.int64),
            }
            logits = self.onnx.run(None, ort_inputs)[0]  # (1, L, V)
            logits_pos = logits[0, pos, :]
            # numerically stable log-softmax
            m = logits_pos.max()
            log_probs = logits_pos - m - np.log(np.exp(logits_pos - m).sum())
            total += float(log_probs[orig_token_id])

        # apply a tiny length penalty (so that extremely long transcriptions are not favored)
        length_score = -self.length_penalty * (int(attn.sum()) - 1)
        return total + length_score

    def _score_with_torch(self, text: str) -> float:
        import torch
        toks = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=self.max_length).to(
            self.device
        )
        input_ids = toks["input_ids"]
        attn = toks["attention_mask"]

        if not self._token_length_ok(input_ids.cpu().numpy()):
            return -1e6

        positions = self._select_mask_positions(input_ids.cpu().numpy(), attn.cpu().numpy())
        if not positions:
            return -1e6

        seq = input_ids[0]
        batch = seq.unsqueeze(0).repeat(len(positions), 1)
        for i, pos in enumerate(positions):
            batch[i, pos] = self.tokenizer.mask_token_id
        batch_attn = attn.repeat(len(positions), 1)
        with torch.no_grad():
            out = self.torch_model(input_ids=batch, attention_mask=batch_attn).logits  # [B, L, V]
            orig = seq.unsqueeze(0).repeat(len(positions), 1)
            rows = torch.arange(len(positions))
            cols = torch.tensor(positions)
            token_ids = orig[rows, cols]
            logits_pos = out[rows, cols, :]
            log_probs = logits_pos.log_softmax(dim=-1)
            picked = log_probs[torch.arange(len(rows)), token_ids]
        total = float(picked.sum().item())
        length_score = -self.length_penalty * (int(attn.sum()) - 1)
        return total + length_score

    def score(self, sentences: List[str]) -> List[float]:
        scorer = self._score_with_onnx if self.onnx is not None else self._score_with_torch
        return [scorer(s) for s in sentences]

    def choose_best(self, candidates: List[str]) -> str:
        # fast-path: if a candidate contains a valid email or phone number, prefer it
        if self.prefer_contact_shortcircuit:
            for c in candidates:
                if self._has_valid_email(c) or self._has_valid_phone(c):
                    return c

        if len(candidates) == 1:
            return candidates[0]

        scores = self.score(candidates)
        # apply a small heuristic bias towards shorter candidates if scores tie closely
        # (helps avoid very long but slightly higher-scoring outputs)
        adjusted = []
        for cand, sc in zip(candidates, scores):
            length = len(self.tokenizer(cand, return_tensors="np", truncation=True, max_length=self.max_length)[
                "input_ids"
            ][0])
            adjusted_score = sc - 1e-4 * length
            adjusted.append(adjusted_score)

        i = int(np.argmax(adjusted))
        return candidates[i]
